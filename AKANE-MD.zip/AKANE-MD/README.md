#Creator ( RICHIE )
<h1 align="center">AKANE-MD <br></h1>
<p align="center">
<img src="https://files.catbox.moe/l9gpzm.jpg" height="300" />
</p>

©2024 - Richie 

multi purpose MD bot first project keep using ill keep updating thanks 🀄.


#Developer ( RICHIE )
©2024 - richie 

